import asyncio
import websockets
import json

# Grading function
def grade_answers(question_set):
    feedback = []
    total_score = 0
    max_score = len(question_set)  # Assuming each question is worth 1 point

    for idx, qa in enumerate(question_set):
        question = qa.get("question", "")
        correct_answer = qa.get("correct_answer", "").strip().lower()
        student_answer = qa.get("student_answer", "").strip().lower()

        if correct_answer == student_answer:
            score = 1
            comment = "Correct!"
        else:
            score = 0
            comment = f"Incorrect. The correct answer is: {correct_answer}"

        total_score += score
        feedback.append({
            "question": question,
            "student_answer": student_answer,
            "score": score,
            "comment": comment
        })

    result = {
        "feedback": feedback,
        "total_score": total_score,
        "max_score": max_score,
        "grade_percentage": (total_score / max_score) * 100
    }

    return result

# WebSocket server handler
async def handler(websocket, path):
    print("Client connected")
    try:
        async for message in websocket:
            print(f"Received message: {message}")

            # Parse the incoming message (assumes JSON format)
            data = json.loads(message)
            question_set = data.get("questions", [])

            # Grade the answers
            grading_result = grade_answers(question_set)

            # Send feedback back to the client
            response = json.dumps(grading_result)
            await websocket.send(response)
            print(f"Sent response: {response}")
    except websockets.ConnectionClosed:
        print("Client disconnected")
    except Exception as e:
        print(f"Error: {e}")

# Start the WebSocket server
async def start_server():
    server = await websockets.serve(handler, "localhost", 6789)
    print("WebSocket server started on ws://localhost:6789")
    await server.wait_closed()

# Run the server
if __name__ == "__main__":
    asyncio.run(start_server())
