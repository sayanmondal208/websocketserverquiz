const WebSocket = require('ws');

// Questions dataset
const questionsSet = [
    { question: "What is 2 + 2?", correctAnswer: "4" },
    { question: "What is the capital of France?", correctAnswer: "Paris" },
    { question: "What is 3 * 3?", correctAnswer: "9" },
    { question: "Who wrote 'Hamlet'?", correctAnswer: "Shakespeare" },
    { question: "What is the square root of 16?", correctAnswer: "4" }
];

// Create a WebSocket server
const wss = new WebSocket.Server({ port: 8080 });
console.log("WebSocket server running on ws://localhost:8080");

// Track client states
const clients = new Map();

wss.on('connection', (ws) => {
    console.log("A new client connected!");

    // Initialize client state
    const clientState = {
        currentQuestionIndex: 0,
        answers: [],
        shuffledQuestions: [...questionsSet].sort(() => 0.5 - Math.random()) // Shuffle questions
    };
    clients.set(ws, clientState);

    // Send the first question
    sendQuestion(ws);

    ws.on('message', (message) => {
        const state = clients.get(ws);

        try {
            const data = JSON.parse(message);

            // Save the answer for the current question
            state.answers.push({
                question: state.shuffledQuestions[state.currentQuestionIndex].question,
                givenAnswer: data.answer,
                correctAnswer: state.shuffledQuestions[state.currentQuestionIndex].correctAnswer
            });

            state.currentQuestionIndex++;

            if (state.currentQuestionIndex < state.shuffledQuestions.length) {
                // Send the next question
                sendQuestion(ws);
            } else {
                // All questions answered, calculate the score
                const score = calculateScore(state.answers);
                ws.send(JSON.stringify({
                    type: "result",
                    score: score,
                    feedback: state.answers
                }));

                // Close the connection after sending the result
                ws.close();
            }
        } catch (error) {
            ws.send(JSON.stringify({ type: "error", message: "Invalid data format" }));
        }
    });

    ws.on('close', () => {
        console.log("Client disconnected");
        clients.delete(ws);
    });
});

function sendQuestion(ws) {
    const state = clients.get(ws);
    const question = state.shuffledQuestions[state.currentQuestionIndex];

    ws.send(JSON.stringify({
        type: "question",
        question: question.question
    }));
}

function calculateScore(answers) {
    let correctCount = 0;

    answers.forEach((answer) => {
        if (answer.givenAnswer.trim().toLowerCase() === answer.correctAnswer.trim().toLowerCase()) {
            correctCount++;
        }
    });

    return {
        totalQuestions: answers.length,
        correctAnswers: correctCount,
        percentage: ((correctCount / answers.length) * 100).toFixed(2)
    };
}
