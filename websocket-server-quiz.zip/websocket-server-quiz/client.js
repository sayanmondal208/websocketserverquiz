const WebSocket = require('ws');
const readline = require('readline');

// WebSocket connection
const ws = new WebSocket('ws://localhost:8080');

// Create an interface for user input
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Handle connection
ws.on('open', () => {
    console.log("Connected to the server.");
});

// Handle incoming messages
ws.on('message', (message) => {
    const data = JSON.parse(message);

    if (data.type === "question") {
        console.log(`Question: ${data.question}`);
        rl.question("Your Answer: ", (answer) => {
            // Send the answer to the server
            ws.send(JSON.stringify({ answer }));
        });
    } else if (data.type === "result") {
        console.log("\nQuiz Complete!");
        console.log(`Score: ${data.score.correctAnswers} / ${data.score.totalQuestions}`);
        console.log(`Percentage: ${data.score.percentage}%`);
        console.log("Feedback:");
        data.feedback.forEach((item, index) => {
            console.log(`${index + 1}. ${item.question}`);
            console.log(`   Your Answer: ${item.givenAnswer}`);
            console.log(`   Correct Answer: ${item.correctAnswer}`);
            console.log(`   ${item.givenAnswer.trim().toLowerCase() === item.correctAnswer.trim().toLowerCase() ? "Correct!" : "Incorrect!"}`);
        });
        rl.close();
    }
});

// Handle errors
ws.on('error', (error) => {
    console.error("WebSocket Error:", error.message);
});

// Handle close
ws.on('close', () => {
    console.log("Disconnected from server.");
    rl.close();
});
